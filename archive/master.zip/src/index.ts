/// <reference path="../node_modules/Bia/bia.d.ts" />
/// <reference path="../node_modules/bia.sdk.api/dist/app/index.d.ts" />
/// <reference path="../node_modules/bia.sdk.api.impl/dist/app/index.d.ts" />